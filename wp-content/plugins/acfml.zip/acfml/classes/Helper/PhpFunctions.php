<?php

namespace ACFML\Helper;

class PhpFunctions {

	/**
	 * @codeCoverageIgnore
	 *
	 * @return void
	 */
	public static function phpExit() {
		exit();
	}
}
